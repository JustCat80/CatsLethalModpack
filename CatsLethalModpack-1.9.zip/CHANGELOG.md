## 1.9

- Update mods
- Remove Depricated [MoreEmotes](https://thunderstore.io/c/lethal-company/p/Sligili/More_Emotes/) mod in favor of the [TooManyEmotes](https://thunderstore.io/c/lethal-company/p/FlipMods/TooManyEmotes/) mod
- Update README

## 1.8.0 - 1.8.5

- Update mods
- Change to the [LethalRichPresence](https://thunderstore.io/c/lethal-company/p/mrov/LethalRichPresence/) mod
- Add CHANGELOG.md
- Update README
- Make the Changelog better (looked at [PupsCuteCosmetics](https://thunderstore.io/c/lethal-company/p/PupVR/Pups_Cute_Cosmetics/changelog/) as a reference)

## 1.7.0 - 1.7.5

- Update for v47
- Add [BetterLobbies](https://thunderstore.io/c/lethal-company/p/Ryokune/Better_Lobbies/)
- Add [PupsCuteCosmetics](https://thunderstore.io/c/lethal-company/p/PupVR/Pups_Cute_Cosmetics/)

## 1.6.0

- Removed [LateCompany](https://thunderstore.io/c/lethal-company/p/anormaltwig/LateCompany/)
- Added [ShipLobby](https://thunderstore.io/c/lethal-company/p/tinyhoot/ShipLobby/)

## 1.4.0

- Change the [DiscordRP](https://thunderstore.io/c/lethal-company/p/Giltong/LethalCompanyDRP/) Mod;
- Add [LCEnhancer](https://thunderstore.io/c/lethal-company/p/Mom_Llama/Lethal_Company_Enhancer/) and some configs

## 1.3.0

- Add [More Terminal Commands](https://thunderstore.io/c/lethal-company/p/NavarroTech/MoreTerminalCommands/) and [FastSwitchPlayerViewInRadar](https://thunderstore.io/c/lethal-company/p/kRYstall9/FastSwitchPlayerViewInRadar/)

## 1.2.1

- Oops fix README

## 1.2.0

- Upload to Github and add a changelog
- Add [QuickTerminalRestart](https://thunderstore.io/c/lethal-company/p/Clementinise/QuickTerminalRestart/) in the hopes that it is fixed