# Cat's Lethal Modpack
A modpack I made for some friends, Its mostly just client side tweaks with the More Company Mod

[Game v62], Everything works (with minimal testing), QuickTerminalRestart functionality unknown

**To join vanilla lobbies you must disable MoreCompany in the mod manager**

If you want something more modded look [Here](https://thunderstore.io/c/lethal-company/p/justcat8/CatsModdedModpack/)

If there are updates to any of the mods, please create an issue or pull request on the [Github Page](https://github.com/JustCat80/CatsLethalModpack)

For updates check the [Changelog](https://thunderstore.io/c/lethal-company/p/justcat8/CatsLethalModpack/changelog/)